(function() {
  const onReady = (fn) => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn, { once: true }) : fn();
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  onReady(() => {
    if (document.getElementById('smeInvBtn')) return;
    let currentLang = 'ar';
    const texts = {
      ar: {
        dir: 'rtl',
        btnFloat: '🧾 الفوترة',
        title: '🧾 إنشاء وتصدير فاتورة',
        langSwitch: 'Français 🇫🇷',
        compAddrPh: 'العنوان (كرمسين، ولاية اترارزة، موريتانيا)',
        compPhonePh: 'هاتف الشركة / السجل التجاري',
        defaultAddr: 'كرمسين، ولاية اترارزة - موريتانيا',
        clientLabel: 'اسم العميل / المشتري:',
        clientPh: 'مثال: شركة التوريد الزراعي',
        defaultClient: 'عميل نقدي',
        invNumLabel: 'رقم الفاتورة:',
        dateLabel: 'التاريخ:',
        addItemTitle: 'إضافة صنف / محصول:',
        itemNamePh: 'اسم المحصول (مثال: بطيخ أحمر)',
        itemQtyPh: 'الكمية',
        itemPricePh: 'السعر',
        addBtn: '+ إضافة',
        thItem: 'الصنف',
        thQty: 'الكمية',
        thPrice: 'السعر',
        thSub: 'المجموع',
        totalLabel: 'الإجمالي الكلي:',
        exportBtn: '📄 تصدير وحفظ الفاتورة (PDF)',
        errInput: 'يرجى إدخال اسم الصنف والكمية والسعر بشكل صحيح',
        errEmpty: 'أضف صنفاً واحداً على الأقل قبل التصدير',
        pdfSubtitle: 'الإنتاج الزراعي والتسويق - كرمسين، موريتانيا',
        pdfBillTo: 'فاتورة إلى:',
        pdfInvNo: 'رقم الفاتورة:',
        pdfDate: 'التاريخ:',
        pdfThDesc: 'البيان / الصنف',
        pdfThUnit: 'سعر الوحدة',
        pdfTotalDue: 'المبلغ الإجمالي المستحق:',
        pdfSign: 'توقيع وختم الإدارة',
        pdfFooter: 'SME Agri - Société Moulay Ely Pour Agricol | شكراً لتعاملكم معنا'
      },
      fr: {
        dir: 'ltr',
        btnFloat: '🧾 Facturation',
        title: '🧾 Créer et Exporter Facture',
        langSwitch: 'العربية 🇸🇦',
        compAddrPh: 'Adresse (Keur Macène, Trarza, Mauritanie)',
        compPhonePh: 'Téléphone / NIF / RC',
        defaultAddr: 'Keur Macène, Wilaya du Trarza - Mauritanie',
        clientLabel: 'Nom du Client / Acheteur :',
        clientPh: 'Ex: Société Agro Distribution',
        defaultClient: 'Client Comptant',
        invNumLabel: 'N° de Facture :',
        dateLabel: 'Date :',
        addItemTitle: 'Ajouter un Produit / Récolte :',
        itemNamePh: 'Nom du produit (Ex: Pastèque)',
        itemQtyPh: 'Quantité',
        itemPricePh: 'Prix Unitaire',
        addBtn: '+ Ajouter',
        thItem: 'Désignation',
        thQty: 'Qté',
        thPrice: 'P.U',
        thSub: 'Total',
        totalLabel: 'Total Général :',
        exportBtn: '📄 Exporter la Facture (PDF)',
        errInput: 'Veuillez saisir le produit, la quantité et le prix',
        errEmpty: 'Veuillez ajouter au moins un article avant d’exporter',
        pdfSubtitle: 'Production et Commercialisation Agricole - Keur Macène, Mauritanie',
        pdfBillTo: 'Facturé à :',
        pdfInvNo: 'Facture N° :',
        pdfDate: 'Date :',
        pdfThDesc: 'Désignation / Produit',
        pdfThUnit: 'Prix Unitaire',
        pdfTotalDue: 'Montant Total à Payer :',
        pdfSign: 'Cachet et Signature de la Direction',
        pdfFooter: 'SME Agri - Société Moulay Ely Pour Agricol | Merci de votre confiance'
      }
    };

    const invBtn = document.createElement('button');
    invBtn.id = 'smeInvBtn';
    invBtn.innerHTML = texts.ar.btnFloat;
    invBtn.style.cssText = 'position:fixed; bottom:78px; left:16px; z-index:9998; background:#d97706; color:#fff; border:none; border-radius:25px; padding:10px 18px; font-weight:bold; font-size:14px; box-shadow:0 4px 12px rgba(0,0,0,0.25); cursor:pointer; font-family:inherit;';
    document.body.appendChild(invBtn);

    const modal = document.createElement('div');
    modal.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(0,0,0,0.65); z-index:9999; overflow-y:auto; padding:16px;';
    document.body.appendChild(modal);

    let items = [];
    let savedClient = '';
    let savedCompAddr = localStorage.getItem('sme_comp_addr') || '';
    let savedCompPhone = localStorage.getItem('sme_comp_phone') || '';
    let savedInvNum = 'INV-' + Math.floor(1000 + Math.random()*9000);
    let savedDate = new Date().toISOString().split('T')[0];

    const renderModal = () => {
      const t = texts[currentLang];
      const alignStart = t.dir === 'rtl' ? 'right' : 'left';
      const alignEnd = t.dir === 'rtl' ? 'left' : 'right';

      modal.style.direction = t.dir;
      modal.innerHTML = `
        <div style="background:#fff; border-radius:16px; max-width:500px; margin:20px auto; padding:20px; box-shadow:0 10px 30px rgba(0,0,0,0.3); color:#1e293b;">
          <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #1a3622; padding-bottom:10px; margin-bottom:12px;">
            <h3 style="margin:0; color:#1a3622; font-size:17px;">${t.title}</h3>
            <div style="display:flex; gap:6px;">
              <button id="toggleInvLang" style="background:#1a3622; color:#fff; border:none; border-radius:8px; padding:5px 10px; font-size:12px; font-weight:bold; cursor:pointer;">${t.langSwitch}</button>
              <button id="closeInvModal" style="background:#ef4444; color:#fff; border:none; border-radius:8px; padding:5px 10px; font-weight:bold; cursor:pointer;">✕</button>
            </div>
          </div>

          <div style="background:#ecfdf5; padding:10px; border-radius:10px; border:1px solid #a7f3d0; margin-bottom:12px;">
            <div style="font-weight:bold; font-size:12px; color:#1a3622; margin-bottom:6px;">🏢 SME Agri - Société Moulay Ely Pour Agricol</div>
            <input id="compAddr" type="text" value="${esc(savedCompAddr)}" placeholder="${t.compAddrPh}" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; margin-bottom:6px; font-size:12px; box-sizing:border-box;">
            <input id="compPhone" type="text" value="${esc(savedCompPhone)}" placeholder="${t.compPhonePh}" style="width:100%; padding:6px; border:1px solid #cbd5e1; border-radius:6px; font-size:12px; box-sizing:border-box;">
          </div>

          <div style="margin-bottom:12px;">
            <label style="display:block; font-size:13px; font-weight:bold; margin-bottom:4px;">${t.clientLabel}</label>
            <input id="invClient" type="text" value="${esc(savedClient)}" placeholder="${t.clientPh}" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:8px; box-sizing:border-box;">
          </div>

          <div style="display:flex; gap:8px; margin-bottom:12px;">
            <div style="flex:1;">
              <label style="display:block; font-size:13px; font-weight:bold; margin-bottom:4px;">${t.invNumLabel}</label>
              <input id="invNum" type="text" value="${savedInvNum}" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:8px; box-sizing:border-box;">
            </div>
            <div style="flex:1;">
              <label style="display:block; font-size:13px; font-weight:bold; margin-bottom:4px;">${t.dateLabel}</label>
              <input id="invDate" type="date" value="${savedDate}" style="width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:8px; box-sizing:border-box;">
            </div>
          </div>

          <div style="background:#f8fafc; padding:10px; border-radius:10px; border:1px solid #e2e8f0; margin-bottom:12px;">
            <div style="font-weight:bold; font-size:13px; color:#1a3622; margin-bottom:8px;">${t.addItemTitle}</div>
            <input id="itemName" type="text" placeholder="${t.itemNamePh}" style="width:100%; padding:7px; border:1px solid #cbd5e1; border-radius:6px; margin-bottom:6px; box-sizing:border-box;">
            <div style="display:flex; gap:6px;">
              <input id="itemQty" type="number" placeholder="${t.itemQtyPh}" style="flex:1; padding:7px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
              <input id="itemPrice" type="number" placeholder="${t.itemPricePh}" style="flex:1; padding:7px; border:1px solid #cbd5e1; border-radius:6px; box-sizing:border-box;">
              <button id="addItemBtn" style="background:#1a3622; color:#fff; border:none; border-radius:6px; padding:0 12px; font-weight:bold; cursor:pointer;">${t.addBtn}</button>
            </div>
          </div>

          <table style="width:100%; border-collapse:collapse; font-size:13px; margin-bottom:12px;">
            <thead>
              <tr style="background:#1a3622; color:#fff;">
                <th style="padding:6px; text-align:${alignStart};">${t.thItem}</th>
                <th style="padding:6px; text-align:center;">${t.thQty}</th>
                <th style="padding:6px; text-align:center;">${t.thPrice}</th>
                <th style="padding:6px; text-align:${alignEnd};">${t.thSub}</th>
              </tr>
            </thead>
            <tbody id="invItemsBody"></tbody>
          </table>

          <div style="background:#fef3c7; padding:10px; border-radius:8px; text-align:${alignEnd}; font-weight:bold; font-size:16px; color:#92400e; margin-bottom:15px;">
            ${t.totalLabel} <span id="invTotal">0</span> MRU
          </div>

          <button id="exportInvPdfBtn" style="width:100%; background:#16a34a; color:#fff; border:none; border-radius:10px; padding:12px; font-size:15px; font-weight:bold; cursor:pointer;">${t.exportBtn}</button>
        </div>
      `;

      const renderItems = () => {
        const tbody = document.getElementById('invItemsBody');
        tbody.innerHTML = '';
        let total = 0;
        items.forEach((it) => {
          const sub = it.qty * it.price;
          total += sub;
          tbody.innerHTML += `<tr style="border-bottom:1px solid #e2e8f0;">
            <td style="padding:6px; text-align:${alignStart};">${esc(it.name)}</td>
            <td style="padding:6px; text-align:center;">${it.qty}</td>
            <td style="padding:6px; text-align:center;">${it.price}</td>
            <td style="padding:6px; text-align:${alignEnd}; font-weight:bold;">${sub.toLocaleString()}</td>
          </tr>`;
        });
        document.getElementById('invTotal').innerText = total.toLocaleString();
      };
      renderItems();

      const readFields = () => {
        savedCompAddr = document.getElementById('compAddr').value.trim();
        savedCompPhone = document.getElementById('compPhone').value.trim();
        savedClient = document.getElementById('invClient').value.trim();
        savedInvNum = document.getElementById('invNum').value.trim() || savedInvNum;
        savedDate = document.getElementById('invDate').value || savedDate;
        localStorage.setItem('sme_comp_addr', savedCompAddr);
        localStorage.setItem('sme_comp_phone', savedCompPhone);
      };

      document.getElementById('closeInvModal').onclick = () => { readFields(); modal.style.display = 'none'; };
      document.getElementById('toggleInvLang').onclick = () => {
        readFields();
        currentLang = currentLang === 'ar' ? 'fr' : 'ar';
        renderModal();
      };

      document.getElementById('addItemBtn').onclick = () => {
        const name = document.getElementById('itemName').value.trim();
        const qty = parseFloat(document.getElementById('itemQty').value);
        const price = parseFloat(document.getElementById('itemPrice').value);
        if (!name || !(qty > 0) || !(price >= 0)) return alert(t.errInput);
        readFields();
        items.push({ name, qty, price });
        renderModal();
      };

      const loadScript = (src) => new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src; s.onload = resolve; s.onerror = () => reject(new Error('تعذر تحميل ' + src));
        document.head.appendChild(s);
      });

      const buildInvoiceHtml = () => {
        const total = items.reduce((a, it) => a + it.qty * it.price, 0);
        const rows = items.map(it => `
          <tr>
            <td style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:${alignStart};">${esc(it.name)}</td>
            <td style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:center;">${it.qty}</td>
            <td style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:center;">${it.price.toLocaleString()}</td>
            <td style="padding:8px; border-bottom:1px solid #e2e8f0; text-align:${alignEnd}; font-weight:bold;">${(it.qty * it.price).toLocaleString()}</td>
          </tr>`).join('');
        return `
          <div style="width:714px; padding:40px; background:#fff; color:#1e293b; direction:${t.dir}; font-family:Cairo, Arial, sans-serif; box-sizing:content-box;">
            <div style="border-bottom:4px solid #1a3622; padding-bottom:12px; margin-bottom:18px;">
              <div style="font-size:24px; font-weight:bold; color:#1a3622;">SME Agri</div>
              <div style="font-size:13px; color:#475569;">Société Moulay Ely Pour Agricol</div>
              <div style="font-size:12px; color:#64748b;">${t.pdfSubtitle}</div>
              <div style="font-size:12px; color:#64748b;">${esc(savedCompAddr || t.defaultAddr)}${savedCompPhone ? ' — ' + esc(savedCompPhone) : ''}</div>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:14px; margin-bottom:18px;">
              <div><div style="color:#64748b;">${t.pdfBillTo}</div><div style="font-weight:bold; font-size:16px;">${esc(savedClient || t.defaultClient)}</div></div>
              <div style="text-align:${alignEnd};"><div>${t.pdfInvNo} <b>${esc(savedInvNum)}</b></div><div>${t.pdfDate} <b>${esc(savedDate)}</b></div></div>
            </div>
            <table style="width:100%; border-collapse:collapse; font-size:14px;">
              <thead><tr style="background:#1a3622; color:#fff;">
                <th style="padding:8px; text-align:${alignStart};">${t.pdfThDesc}</th>
                <th style="padding:8px; text-align:center;">${t.thQty}</th>
                <th style="padding:8px; text-align:center;">${t.pdfThUnit}</th>
                <th style="padding:8px; text-align:${alignEnd};">${t.thSub}</th>
              </tr></thead>
              <tbody>${rows}</tbody>
            </table>
            <div style="margin-top:18px; background:#fef3c7; padding:12px; border-radius:8px; font-size:17px; font-weight:bold; color:#92400e; text-align:${alignEnd};">
              ${t.pdfTotalDue} ${total.toLocaleString()} MRU
            </div>
            <div style="margin-top:50px; font-size:13px; color:#475569; text-align:${alignEnd};">${t.pdfSign}<div style="margin-top:40px; border-top:1px solid #94a3b8; width:180px; display:inline-block;"></div></div>
            <div style="margin-top:40px; text-align:center; font-size:11px; color:#94a3b8;">${t.pdfFooter}</div>
          </div>`;
      };

      document.getElementById('exportInvPdfBtn').onclick = async () => {
        readFields();
        if (items.length === 0) return alert(t.errEmpty);
        const btn = document.getElementById('exportInvPdfBtn');
        const oldLabel = btn.innerText;
        btn.disabled = true; btn.innerText = '⏳ ...';
        const holder = document.createElement('div');
        holder.style.cssText = 'position:fixed; left:-10000px; top:0;';
        holder.innerHTML = buildInvoiceHtml();
        document.body.appendChild(holder);
        try {
          if (!window.html2canvas) await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
          if (!(window.jspdf && window.jspdf.jsPDF)) await loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
          if (document.fonts && document.fonts.ready) await document.fonts.ready;
          const canvas = await window.html2canvas(holder.firstElementChild, { scale: 2, backgroundColor: '#ffffff' });
          const pdf = new window.jspdf.jsPDF({ unit: 'mm', format: 'a4' });
          const pageW = pdf.internal.pageSize.getWidth();
          const pageH = pdf.internal.pageSize.getHeight();
          const imgH = Math.min(canvas.height * pageW / canvas.width, pageH);
          pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pageW, imgH);

          // الاسم يبدأ بـ INV- ليُؤرشف تلقائياً في مركز القيادة
          const safeNum = savedInvNum.replace(/[^\w\-]+/g, '_');
          const fileName = (safeNum.toUpperCase().startsWith('INV-') ? safeNum : 'INV-' + safeNum) + '.pdf';
          if (window.Capacitor && window.saveNativeBase64File) {
            const b64 = pdf.output('datauristring').split(',')[1];
            await window.saveNativeBase64File(b64, fileName);
          } else {
            pdf.save(fileName);
          }
        } catch (err) {
          alert('⚠️ تعذر إنشاء الفاتورة: ' + err.message + '\n(يلزم اتصال بالإنترنت لأول تصدير)');
        } finally {
          holder.remove();
          btn.disabled = false; btn.innerText = oldLabel;
        }
      };
    };

    invBtn.onclick = () => { renderModal(); modal.style.display = 'block'; };
  });
})();
